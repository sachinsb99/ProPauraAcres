import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [message, setMessage] = useState('');
  const [formResponse, setFormResponse] = useState('');

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/test')
      .then(response => {
        setMessage(response.data.message);
      })
      .catch(error => {
        console.error("GET error:", error.message);
      });
  }, []);

  const handleSubmit = () => {
    console.log("Submit button clicked");

    axios.post('http://127.0.0.1:10000/api/test-form', {
      name: 'John Doe',
      email: 'john@example.com',
      message: 'Hello from React!'
    })
    .then(response => {
      console.log("POST success:", response.data);
      setFormResponse(response.data.message);
    })
    .catch(error => {
      console.error("POST error:", error.response?.data || error.message);
    });
  };

  return (
    <div style={{ padding: 40 }}>
      <h1>React + Laravel API</h1>
      <p><strong>GET API Response:</strong> {message}</p>
      <button onClick={handleSubmit}>Submit Form</button>
      <p><strong>POST API Response:</strong> {formResponse}</p>
    </div>
  );
}

export default App;
