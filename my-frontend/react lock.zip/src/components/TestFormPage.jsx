import React, { useState } from 'react';

export default function TestFormPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResponse(null);

    try {
      // Replace with your Laravel backend URL
      const res = await fetch('http://localhost:8000/api/test-form', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (res.ok) {
        setResponse(data);
        setFormData({ name: '', email: '', message: '' });
      } else {
        setError(data.message || 'Something went wrong');
      }
    } catch (err) {
      setError('Network error: Unable to connect to backend');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Laravel + React Test
          </h1>
          <p className="text-gray-600">
            Test form to verify backend and frontend connection
          </p>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6">
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter your name"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter your message"
              />
            </div>

            <button
              onClick={handleSubmit}
              disabled={loading}
              className={`w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white 
                ${loading 
                  ? 'bg-gray-400 cursor-not-allowed' 
                  : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
                }`}
            >
              {loading ? 'Sending...' : 'Submit Form'}
            </button>
          </div>

          {/* Success Response */}
          {response && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-md">
              <h3 className="text-green-800 font-medium mb-2">✅ Success!</h3>
              <pre className="text-sm text-green-700 whitespace-pre-wrap">
                {JSON.stringify(response, null, 2)}
              </pre>
            </div>
          )}

          {/* Error Response */}
          {error && (
            <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-md">
              <h3 className="text-red-800 font-medium mb-2">❌ Error</h3>
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          {/* Connection Status */}
          <div className="mt-6 p-3 bg-blue-50 border border-blue-200 rounded-md">
            <h4 className="text-blue-800 font-medium text-sm mb-2">Backend Connection:</h4>
            <p className="text-blue-700 text-xs">
              Expecting POST endpoint at: <code>http://localhost:8000/api/test-form</code>
            </p>
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-8 bg-white shadow-md rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-3">Laravel Backend Setup</h3>
          <div className="text-sm text-gray-600 space-y-2">
            <p><strong>1. Add this route to your Laravel routes/api.php:</strong></p>
            <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">
{`Route::post('/test-form', function (Request $request) {
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email',
        'message' => 'required|string'
    ]);

    return response()->json([
        'status' => 'success',
        'message' => 'Form submitted successfully!',
        'data' => $validated,
        'timestamp' => now()
    ]);
});`}</pre>
            
            <p><strong>2. Enable CORS in your Laravel app</strong> (if not already done)</p>
            <p><strong>3. Make sure your Laravel server is running on port 8000</strong></p>
            <p><strong>4. Update the API URL in the React component if needed</strong></p>
          </div>
        </div>
      </div>
    </div>
  );
}