import React from 'react';

export default function HomePage() {
  return (
    <div className="text-center p-10">
      <h1 className="text-3xl font-bold text-gray-800">Welcome to Home Page</h1>
    </div>
  );
}